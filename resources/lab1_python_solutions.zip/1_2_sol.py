txt = "How I need a drink alcoholic of course, after all those lectures involving quantum mechanics"

for w in txt.split():
    print(len(w),sep="", end="")