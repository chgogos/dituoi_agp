negateList :: Num b => [b] -> [b]
negateList xs = map negate xs
