philosopher(socrates).
philosopher(plato).
politician(pericles).

human(X):- philosopher(X).
human(X):- politician(X).
mammal(X):- human(X).
mortal(X):- mammal(X).

% Βάση γνώσης
% 7 clauses (προτάσεις)
% 3 facts (γεγονότα)
% 4 rules (κανόνες)
% 5 predicates (κατηγορήματα) : philosopher\1, politician\1, human\1, mammal\1, mortal\1 
% 3 atomic terms (ατομικοί όροι) : socrates, plato, pericles
% 1 variable (μεταβλητή): X

% Ερώτημα 1: Είναι ο Σωκράτης φιλόσοφος;
% ?- philosopher(socrates).
% true.

% Ερώτημα 2: Είναι ο Περικλής φιλόσοφος;
% ?- philosopher(pericles).
% false.

% Ερώτημα 3: Είναι ο Σωκράτης θηλαστικό;
% ?- mammal(socrates).      
% true .

% Ερώτημα 4: Είναι ο Περικλής θνητός;
% ?- mortal(pericles). 
% true.

% Ερώτημα 5: Ποιοι οντότητες είναι θνητές στη βάση γνώσης;
% ?- mortal(X).             
% X = socrates ;
% X = plato ;
% X = pericles.
