parent(a,b).
parent(a,c). 
parent(b,d). 
parent(b,e).  
parent(c,f).  

sibling(X,Y) :- parent(Z,X), parent(Z,Y), not(X=Y).
cousin(X,Y) :- parent(Z,X), parent(W,Y), sibling(Z,W). 
grandchild(X,Y) :- parent(Z,X), parent(Y,Z).
descendent(X,Y) :- parent(Y,X).
descendent(X,Y) :- parent(Z,X), descendent(Z,Y).

% Ερώτηση 1: Εμφανίστε τα ζεύγη των αδερφιών.
% ?- sibling(X,Y).
% X = b,
% Y = c ;
% X = c,
% Y = b ;
% X = d,
% Y = e ;
% X = e,
% Y = d ;
% false.

% ή 

% ?- sibling(X,Y), format('~s ~s\n', [X,Y]), fail. 
% b c
% c b
% d e
% e d

% Ερώτηση 2: Εμφανίστε τα ζεύγη των ξαδερφιών.
% ?- cousin(X,Y).
% X = d,
% Y = f ;
% X = e,
% Y = f ;
% X = f,
% Y = d ;
% X = f,
% Y = e ;
% false.

% Ερώτηση 3: Εμφανίστε τα εγγόνια του a.
% ?- grandchild(X,a). 
% X = d ;
% X = e ;
% X = f.

% Ερώτηση 4: Εμφανίστε τους απογόνους του a.
% ?- descendent(X,a).
% X = b ;
% X = c ;
% X = d ;
% X = e ;
% X = f ;
% false.